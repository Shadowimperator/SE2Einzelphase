package com.example.se2project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.*;
import android.view.View;
import android.widget.*;

import java.io.*;
import java.net.Socket;
import java.math.BigInteger;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = (Button) findViewById(R.id.button);
        EditText input = (EditText) findViewById(R.id.inputText);
        TextView outputViewServer = (TextView) findViewById(R.id.outputViewServer);
        TextView outputViewMethod = (TextView) findViewById(R.id.outputViewMethod);


        input.addTextChangedListener(new TextWatcher() {
            String newInput = "";
            public void afterTextChanged(Editable s) {
                newInput = input.getText().toString().trim();
                if(newInput.matches("")) {input.setText("0");}
                else{
                    newInput = removeInitialZeros(newInput);
                }
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            public void onTextChanged(CharSequence s, int start, int before, int count) {
                newInput = input.getText().toString();
            }
        });


        button.setOnClickListener(new View.OnClickListener() {
            String newInput = input.getText().toString().trim();
            public void onClick(View v) {
                if(checkOnlyNumbers(newInput) == true){
                    newInput = removeInitialZeros(newInput);
                    int matricola = Integer.parseInt(newInput); //personal matricola: 11926225
                    Socket socket;
                    try {
                        socket = new Socket("se2-isys.aau.at", 53212);
                        OutputStream output = socket.getOutputStream();
                        BigInteger bigInt = BigInteger.valueOf(matricola);
                        byte[] data = bigInt.toByteArray();
                        output.write(data);
                        //---------------------------------------------------------------
                        InputStream inputStream = socket.getInputStream();
                        InputStreamReader reader = new InputStreamReader(inputStream);
                        inputStream.read(data);
                        int characters;
                        StringBuilder ret_Data = new StringBuilder();
                        while ((characters = reader.read()) != -1) {
                            ret_Data.append((char) characters);
                        }
                        outputViewServer.setText(ret_Data);
                        socket.close();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    switch(matricola % 7){
                        case 0:
                            break;
                        case 1:
                            break;
                        case 2:
                            break;
                        case 3: // 11926225 mod 7 = 3
                            outputViewMethod.setText(method3(matricola));
                            break;
                        case 4:
                            break;
                        case 5:
                            break;
                        case 6:
                            break;
                    }
                }else{
                    input.setText("0");
                }
            }
        });
    }

    public static boolean checkOnlyNumbers(String text){
        char[] chars = text.toCharArray();
        for(char c : chars){
            if(!Character.isDigit(c)){return false;}
        }
        return true;
    }

    public static String removeInitialZeros(String text){
        for(int i=0; i<text.length(); i++){
            if(text.charAt(i) != '0'){
                text = text.substring(i);
            }
        }
        return text;
    }

    public static void method1(int m){}

    public static void method2(int m){}

    public static StringBuilder method3(int m){
        StringBuilder sb = new StringBuilder();
        byte nums[] = BigInteger.valueOf(m).toByteArray();
        for(int i = 1; i <= nums.length; i++) {
            if(i % 2 == 0){
                sb.append(getEvenChar(nums[i]));
            }else{sb.append(nums[i]);}
        }
        return sb;
    }

    public static void method4(int m){}

    public static void method5(int m){}

    public static void method6(int m){}

    public static char getEvenChar(byte n){
        char c = ' ';
        switch(n){
            case 0:
                c = 'j';
                break;
            case 1:
                c = 'a';
                break;
            case 2:
                c = 'b';
                break;
            case 3:
                c = 'c';
                break;
            case 4:
                c = 'd';
                break;
            case 5:
                c = 'e';
                break;
            case 6:
                c = 'f';
                break;
            case 7:
                c = 'g';
                break;
            case 8:
                c = 'h';
                break;
            case 9:
                c = 'i';
                break;
        }
        return c;
    }
}