package com.example.se2project;

import java.io.*;
import java.net.Socket;

public class Client implements Runnable{
    int m;
    String data;
    String dataFromServer;
    public Client(int matricola){
        m = matricola;
    }
    public void run(){
        try {
            Socket socket = new Socket("se2-isys.aau.at", 53212);
            //BufferedReader readUser = new BufferedReader(new InputStreamReader(System.in));
            DataOutputStream outToServer = new DataOutputStream(socket.getOutputStream());
            BufferedReader readServer = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            data = "" + m;
            outToServer.writeBytes(data + '\n');
            dataFromServer = readServer.readLine();
            System.out.println("Server output:" + dataFromServer);
            socket.close();
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public String returnAnswerFromServer(){
        return dataFromServer;
    }
}
