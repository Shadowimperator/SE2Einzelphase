package com.example.se2project;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.*;
import android.view.View;
import android.widget.*;

import java.io.*;
import java.net.Socket;
import java.math.BigInteger;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = (Button) findViewById(R.id.button);
        EditText input = (EditText) findViewById(R.id.editTextNumber);
        TextView outputViewServer = (TextView) findViewById(R.id.outputViewServer);
        TextView outputViewMethod = (TextView) findViewById(R.id.outputViewMethod);

/*
        input.addTextChangedListener(new TextWatcher() {
            String newInput = "";
            public void afterTextChanged(Editable s) {
                newInput = input.getText().toString().trim();
                if(newInput.matches("")) {input.setText("0");}
                else{
                    newInput = removeInitialZeros(newInput);
                }
            }

            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            public void onTextChanged(CharSequence s, int start, int before, int count) {
                newInput = input.getText().toString();
            }
        });
*/

        System.out.println("input is: " + input);
        button.setOnClickListener(new View.OnClickListener() {
            String newInput = input.getText().toString().trim();
            public void onClick(View v) {
                if(checkOnlyNumbers(newInput) == true){
                    System.out.println("input is: " + newInput);
                    //newInput = removeInitialZeros(newInput);
                    //int matricola = Integer.parseInt(newInput); //personal matricola: 11926225
                    int matricola = 11926225;
                    Client c = new Client(matricola);
                    new Thread(c).start();
                    outputViewServer.setText(c.returnAnswerFromServer());

                    String res;
                    switch(matricola % 7){
                        case 0:
                            break;
                        case 1:
                            break;
                        case 2:
                            break;
                        case 3: // 11926225 mod 7 = 3
                            res = method3(matricola);
                            outputViewMethod.setText(res);
                            System.out.println("Method output : " + res);
                            break;
                        case 4:
                            break;
                        case 5:
                            break;
                        case 6:
                            break;
                    }
                }else{
                    input.setText("0");
                }
            }
        });
    }

    public static boolean checkOnlyNumbers(String text){
        char[] chars = text.toCharArray();
        for(char c : chars){
            if(!Character.isDigit(c)){return false;}
        }
        return true;
    }

    public static String removeInitialZeros(String text){
        for(int i=0; i<text.length(); i++){
            if(text.charAt(i) != '0'){
                text = text.substring(i);
            }
        }
        return text;
    }

    public static void method1(int m){}

    public static void method2(int m){}

    public static String method3(int m){
        String sb = "";
        char nums[] = ("" + m).toCharArray();
        for(int i = 0; i < nums.length; i++) {
            if((i+1) % 2 == 0){
                sb = sb + getEvenChar(nums[i]);
            }else{sb = sb + nums[i];}
        }
        return sb;
    }

    public static void method4(int m){}

    public static void method5(int m){}

    public static void method6(int m){}

    public static char getEvenChar(char n){
        char c = ' ';
        switch(n){
            case '0':
                c = 'j';
                break;
            case '1':
                c = 'a';
                break;
            case '2':
                c = 'b';
                break;
            case '3':
                c = 'c';
                break;
            case '4':
                c = 'd';
                break;
            case '5':
                c = 'e';
                break;
            case '6':
                c = 'f';
                break;
            case '7':
                c = 'g';
                break;
            case '8':
                c = 'h';
                break;
            case '9':
                c = 'i';
                break;
        }
        return c;
    }

}

