package com.example.se2_project_attempt3;

import java.io.*;
import java.net.Socket;
import java.util.concurrent.Callable;

public class Client implements Callable<String> {
    int m;
    String data;
    String dataFromServer = "hello";
    public Client(int matricola){
        m = matricola;
    }

    public void setDataFromServer(String line){
        this.dataFromServer = line;
    }
    public String call() throws Exception{
        try {
            Socket socket = new Socket("se2-isys.aau.at", 53212);
            //BufferedReader readUser = new BufferedReader(new InputStreamReader(System.in));
            DataOutputStream outToServer = new DataOutputStream(socket.getOutputStream());
            BufferedReader readServer = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            data = "" + m;
            outToServer.writeBytes(data + '\n');
            dataFromServer = readServer.readLine();
            System.out.println("Server output:" + dataFromServer);
            socket.close();
        }catch(Exception e){
            e.printStackTrace();
        }
        return dataFromServer;
    }
}
