package com.example.se2_project_attempt3;

public class SecondMethod {
    int m;
    String res;

    public SecondMethod(int matricola){
        m = matricola;
    }

    public void executeMethod(){
        switch(m % 7){
            case 0:
                method0(m);
                break;
            case 1:
                method1(m);
                break;
            case 2:
                method2(m);
                break;
            case 3: // 11926225 mod 7 = 3
                res = method3(m);
                break;
            case 4:
                method4(m);
                break;
            case 5:
                method5(m);
                break;
            case 6:
                method6(m);
                break;
        }
    }
    public void method0(int m){}

    public void method1(int m){}

    public void method2(int m){}

    public String method3(int m){
        String sb = "";
        char nums[] = ("" + m).toCharArray();
        for(int i = 0; i < nums.length; i++) {
            if ((i + 1) % 2 == 0) {
                sb = sb + getEvenChar(nums[i]);
            } else {
                sb = sb + nums[i];
            }
            res = sb;
        }
        return sb;
    }

    public void method4(int m){}

    public void method5(int m){}

    public void method6(int m){}

    public char getEvenChar(char n){
        char c = ' ';
        switch(n){
            case '0':
                c = 'j';
                break;
            case '1':
                c = 'a';
                break;
            case '2':
                c = 'b';
                break;
            case '3':
                c = 'c';
                break;
            case '4':
                c = 'd';
                break;
            case '5':
                c = 'e';
                break;
            case '6':
                c = 'f';
                break;
            case '7':
                c = 'g';
                break;
            case '8':
                c = 'h';
                break;
            case '9':
                c = 'i';
                break;
        }
        return c;
    }

    public String returnOutputFromMethod(){
        return res;
    }
}