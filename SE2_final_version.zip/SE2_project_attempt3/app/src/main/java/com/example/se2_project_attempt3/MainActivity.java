package com.example.se2_project_attempt3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.*;

import java.util.concurrent.*;

public class MainActivity extends AppCompatActivity {

    Button button;
    TextView outputViewServer, outputViewMethod;
    EditText input;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button = (Button) findViewById(R.id.button);
        input = (EditText) findViewById(R.id.editTextNumber);
        outputViewServer = (TextView) findViewById(R.id.outputViewServer);
        outputViewMethod = (TextView) findViewById(R.id.outputViewMethod);

        String newInput = input.getText().toString().trim();

        System.out.println("input is: " + input);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String newInput = input.getText().toString();
                System.out.println("input is: " + newInput);
                int matricola = Integer.parseInt(newInput); //personal matricola: 11926225

                ExecutorService executor = Executors.newFixedThreadPool(10);
                Client c = new Client(matricola);
                Future<String> clientOut = executor.submit(c);
                try {
                    outputViewServer.setText("" + clientOut.get());
                }catch(Exception e){
                    e.printStackTrace();
                }
                executor.shutdown();

                SecondMethod method = new SecondMethod(matricola);
                method.executeMethod();
                outputViewMethod.setText(method.returnOutputFromMethod());
            }
        });
    }

    public static String removeInitialZeros(String text){
        for(int i=0; i<text.length(); i++){
            if(text.charAt(i) != '0'){
                text = text.substring(i);
            }
        }
        return text;
    }
}